import { useState } from "react";
import LoginPage from "@/components/LoginPage";
import MainPanel from "@/components/MainPanel";
import { Toaster } from "@/components/ui/sonner";

const Index = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <div className="dark">
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: 'hsl(0 0% 7%)',
            border: '1px solid hsl(0 60% 22%)',
            color: 'hsl(0 10% 92%)',
            fontFamily: 'Share Tech Mono, monospace',
          },
        }}
      />
      {isAuthenticated ? (
        <MainPanel onLogout={() => setIsAuthenticated(false)} />
      ) : (
        <LoginPage onLogin={() => setIsAuthenticated(true)} />
      )}
    </div>
  );
};

export default Index;
