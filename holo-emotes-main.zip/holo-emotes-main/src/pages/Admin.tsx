import { useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import AdminLogin from '@/components/AdminLogin';
import AdminPanel from '@/components/AdminPanel';
import { useNavigate } from 'react-router-dom';

const Admin = () => {
  const [authed, setAuthed] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="dark">
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: 'hsl(0 0% 7%)',
            border: '1px solid hsl(0 60% 22%)',
            color: 'hsl(0 10% 92%)',
            fontFamily: 'Share Tech Mono, monospace',
          },
        }}
      />
      {authed ? (
        <AdminPanel onLogout={() => { setAuthed(false); navigate('/'); }} />
      ) : (
        <AdminLogin onLogin={() => setAuthed(true)} />
      )}
    </div>
  );
};

export default Admin;
