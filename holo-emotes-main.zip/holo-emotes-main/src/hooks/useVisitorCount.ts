import { useState, useEffect } from 'react';

const VISITOR_KEY = 'unknown_codex_visitors';
const VISITOR_ID_KEY = 'unknown_codex_visitor_id';

export const useVisitorCount = () => {
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    const storedCount = localStorage.getItem(VISITOR_KEY);
    const visitorId = localStorage.getItem(VISITOR_ID_KEY);
    
    let currentCount = storedCount ? parseInt(storedCount, 10) : 0;
    
    if (!visitorId) {
      const newId = `visitor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem(VISITOR_ID_KEY, newId);
      currentCount += 1;
      localStorage.setItem(VISITOR_KEY, currentCount.toString());
    }
    
    setCount(currentCount);
  }, []);

  return count;
};
