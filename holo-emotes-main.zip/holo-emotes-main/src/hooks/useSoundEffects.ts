import { useEffect, useRef, useCallback } from 'react';

const CLICK_SOUND_URL = 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3';
const SUCCESS_SOUND_URL = 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3';
const ERROR_SOUND_URL = 'https://assets.mixkit.co/active_storage/sfx/2955/2955-preview.mp3';

export const useSoundEffects = () => {
  const clickAudioRef = useRef<HTMLAudioElement | null>(null);
  const successAudioRef = useRef<HTMLAudioElement | null>(null);
  const errorAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    clickAudioRef.current = new Audio(CLICK_SOUND_URL);
    successAudioRef.current = new Audio(SUCCESS_SOUND_URL);
    errorAudioRef.current = new Audio(ERROR_SOUND_URL);

    clickAudioRef.current.volume = 0.3;
    successAudioRef.current.volume = 0.4;
    errorAudioRef.current.volume = 0.3;
  }, []);

  const playClick = useCallback(() => {
    if (clickAudioRef.current) {
      clickAudioRef.current.currentTime = 0;
      clickAudioRef.current.play().catch(() => {});
    }
  }, []);

  const playSuccess = useCallback(() => {
    if (successAudioRef.current) {
      successAudioRef.current.currentTime = 0;
      successAudioRef.current.play().catch(() => {});
    }
  }, []);

  const playError = useCallback(() => {
    if (errorAudioRef.current) {
      errorAudioRef.current.currentTime = 0;
      errorAudioRef.current.play().catch(() => {});
    }
  }, []);

  return { playClick, playSuccess, playError };
};
