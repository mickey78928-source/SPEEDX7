import { useState, useEffect } from 'react';

const FAVORITES_KEY = 'unknown_codex_favorites';

export const useFavorites = () => {
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(FAVORITES_KEY);
    if (stored) {
      try {
        setFavorites(JSON.parse(stored));
      } catch {
        setFavorites([]);
      }
    }
  }, []);

  const toggleFavorite = (emoteId: string) => {
    setFavorites(prev => {
      const newFavorites = prev.includes(emoteId)
        ? prev.filter(id => id !== emoteId)
        : [...prev, emoteId];
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
      return newFavorites;
    });
  };

  const isFavorite = (emoteId: string) => favorites.includes(emoteId);

  return { favorites, toggleFavorite, isFavorite };
};
