import { useState, useEffect } from 'react';

const HISTORY_KEY = 'unknown_codex_history';
const MAX_HISTORY = 12;

export const useEmoteHistory = () => {
  const [history, setHistory] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(HISTORY_KEY);
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch {
        setHistory([]);
      }
    }
  }, []);

  const addToHistory = (emoteId: string) => {
    setHistory(prev => {
      const filtered = prev.filter(id => id !== emoteId);
      const newHistory = [emoteId, ...filtered].slice(0, MAX_HISTORY);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
      return newHistory;
    });
  };

  return { history, addToHistory };
};
