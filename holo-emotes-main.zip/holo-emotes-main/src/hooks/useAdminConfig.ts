import { useState, useEffect, useCallback } from 'react';

const API_URL_KEY = 'unknown_codex_api_url';
const API_PATH_KEY = 'unknown_codex_api_path';
const USER_PASS_KEY = 'unknown_codex_user_password';
const ADMIN_PASS_KEY = 'unknown_codex_admin_password';
const BOT_TCS_KEY = 'unknown_codex_bot_tcs';
const ANNOUNCEMENT_KEY = 'unknown_codex_announcement';
const MAINTENANCE_KEY = 'unknown_codex_maintenance';
const KILLSWITCH_KEY = 'unknown_codex_killswitch';
const MAX_UIDS_KEY = 'unknown_codex_max_uids';
const APP_NAME_KEY = 'unknown_codex_app_name';

export const DEFAULT_API_URL = 'https://exu-api-2.onrender.com';
export const DEFAULT_API_PATH = '/join';
export const DEFAULT_USER_PASSWORD = '60';
export const DEFAULT_ADMIN_PASSWORD = 'EXU-1CF1J8RW';
export const DEFAULT_BOT_TCS = ['1694161', '3859281'];
export const DEFAULT_MAX_UIDS = 6;
export const DEFAULT_APP_NAME = 'EMOTE HUB';

export const getApiUrl = () => {
  const v = localStorage.getItem(API_URL_KEY);
  if (v) return v;
  // Migrate any older saved value that included a path
  return DEFAULT_API_URL;
};
export const getApiPath = () => {
  const v = localStorage.getItem(API_PATH_KEY);
  return v !== null ? v : DEFAULT_API_PATH;
};
export const getFullApiUrl = () => {
  const base = getApiUrl().replace(/\/+$/, '');
  let path = getApiPath().trim();
  if (path && !path.startsWith('/')) path = '/' + path;
  return base + path;
};
export const getUserPassword = () =>
  localStorage.getItem(USER_PASS_KEY) || DEFAULT_USER_PASSWORD;
export const getAdminPassword = () =>
  localStorage.getItem(ADMIN_PASS_KEY) || DEFAULT_ADMIN_PASSWORD;
export const getBotTcs = (): string[] => {
  const raw = localStorage.getItem(BOT_TCS_KEY);
  if (!raw) return DEFAULT_BOT_TCS;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string') : DEFAULT_BOT_TCS;
  } catch { return DEFAULT_BOT_TCS; }
};
export const getAnnouncement = () => localStorage.getItem(ANNOUNCEMENT_KEY) || '';
export const getMaintenance = () => localStorage.getItem(MAINTENANCE_KEY) === '1';
export const getKillSwitch = () => localStorage.getItem(KILLSWITCH_KEY) === '1';
export const getMaxUids = () => {
  const v = parseInt(localStorage.getItem(MAX_UIDS_KEY) || '', 10);
  return isNaN(v) || v < 1 || v > 12 ? DEFAULT_MAX_UIDS : v;
};
export const getAppName = () => localStorage.getItem(APP_NAME_KEY) || DEFAULT_APP_NAME;

export const useAdminConfig = () => {
  const [apiUrl, setS_api] = useState(getApiUrl());
  const [apiPath, setS_path] = useState(getApiPath());
  const [userPassword, setS_userPass] = useState(getUserPassword());
  const [adminPassword, setS_adminPass] = useState(getAdminPassword());
  const [botTcs, setS_bots] = useState(getBotTcs());
  const [announcement, setS_ann] = useState(getAnnouncement());
  const [maintenance, setS_maint] = useState(getMaintenance());
  const [killSwitch, setS_kill] = useState(getKillSwitch());
  const [maxUids, setS_max] = useState(getMaxUids());
  const [appName, setS_name] = useState(getAppName());

  useEffect(() => {
    const onStorage = () => {
      setS_api(getApiUrl()); setS_path(getApiPath());
      setS_userPass(getUserPassword()); setS_adminPass(getAdminPassword());
      setS_bots(getBotTcs()); setS_ann(getAnnouncement()); setS_maint(getMaintenance());
      setS_kill(getKillSwitch()); setS_max(getMaxUids()); setS_name(getAppName());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const setApiUrl = useCallback((v: string) => { localStorage.setItem(API_URL_KEY, v); setS_api(v); }, []);
  const resetApiUrl = useCallback(() => { localStorage.removeItem(API_URL_KEY); setS_api(DEFAULT_API_URL); }, []);
  const setApiPath = useCallback((v: string) => { localStorage.setItem(API_PATH_KEY, v); setS_path(v); }, []);
  const resetApiPath = useCallback(() => { localStorage.removeItem(API_PATH_KEY); setS_path(DEFAULT_API_PATH); }, []);
  const setUserPassword = useCallback((v: string) => { localStorage.setItem(USER_PASS_KEY, v); setS_userPass(v); }, []);
  const setAdminPassword = useCallback((v: string) => { localStorage.setItem(ADMIN_PASS_KEY, v); setS_adminPass(v); }, []);
  const setBotTcs = useCallback((list: string[]) => { localStorage.setItem(BOT_TCS_KEY, JSON.stringify(list)); setS_bots(list); }, []);
  const addBotTc = useCallback((tc: string) => {
    const list = [...getBotTcs(), tc];
    localStorage.setItem(BOT_TCS_KEY, JSON.stringify(list)); setS_bots(list);
  }, []);
  const removeBotTc = useCallback((tc: string) => {
    const list = getBotTcs().filter((x) => x !== tc);
    localStorage.setItem(BOT_TCS_KEY, JSON.stringify(list)); setS_bots(list);
  }, []);
  const setAnnouncement = useCallback((v: string) => { localStorage.setItem(ANNOUNCEMENT_KEY, v); setS_ann(v); }, []);
  const setMaintenance = useCallback((v: boolean) => { localStorage.setItem(MAINTENANCE_KEY, v ? '1' : '0'); setS_maint(v); }, []);
  const setKillSwitch = useCallback((v: boolean) => { localStorage.setItem(KILLSWITCH_KEY, v ? '1' : '0'); setS_kill(v); }, []);
  const setMaxUids = useCallback((v: number) => { localStorage.setItem(MAX_UIDS_KEY, String(v)); setS_max(v); }, []);
  const setAppName = useCallback((v: string) => { localStorage.setItem(APP_NAME_KEY, v); setS_name(v); }, []);

  const exportConfig = useCallback(() => ({
    apiUrl: getApiUrl(),
    apiPath: getApiPath(),
    userPassword: getUserPassword(),
    adminPassword: getAdminPassword(),
    botTcs: getBotTcs(),
    announcement: getAnnouncement(),
    maintenance: getMaintenance(),
    killSwitch: getKillSwitch(),
    maxUids: getMaxUids(),
    appName: getAppName(),
  }), []);

  const importConfig = useCallback((cfg: Record<string, unknown>) => {
    if (typeof cfg.apiUrl === 'string') setApiUrl(cfg.apiUrl);
    if (typeof cfg.apiPath === 'string') setApiPath(cfg.apiPath);
    if (typeof cfg.userPassword === 'string') setUserPassword(cfg.userPassword);
    if (typeof cfg.adminPassword === 'string') setAdminPassword(cfg.adminPassword);
    if (Array.isArray(cfg.botTcs)) setBotTcs(cfg.botTcs.filter((x): x is string => typeof x === 'string'));
    if (typeof cfg.announcement === 'string') setAnnouncement(cfg.announcement);
    if (typeof cfg.maintenance === 'boolean') setMaintenance(cfg.maintenance);
    if (typeof cfg.killSwitch === 'boolean') setKillSwitch(cfg.killSwitch);
    if (typeof cfg.maxUids === 'number') setMaxUids(cfg.maxUids);
    if (typeof cfg.appName === 'string') setAppName(cfg.appName);
  }, [setApiUrl, setApiPath, setUserPassword, setAdminPassword, setBotTcs, setAnnouncement, setMaintenance, setKillSwitch, setMaxUids, setAppName]);

  return {
    apiUrl, setApiUrl, resetApiUrl,
    apiPath, setApiPath, resetApiPath,
    userPassword, setUserPassword,
    adminPassword, setAdminPassword,
    botTcs, setBotTcs, addBotTc, removeBotTc,
    announcement, setAnnouncement,
    maintenance, setMaintenance,
    killSwitch, setKillSwitch,
    maxUids, setMaxUids,
    appName, setAppName,
    exportConfig, importConfig,
  };
};

