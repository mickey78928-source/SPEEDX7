import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Zap, LogOut, Terminal, User, Hash, Plus, Minus, Megaphone, WifiOff, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ParticleBackground from './ParticleBackground';
import EmoteGrid from './EmoteGrid';
import { useFavorites } from '@/hooks/useFavorites';
import { useEmoteHistory } from '@/hooks/useEmoteHistory';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { toast } from 'sonner';
import { getFullApiUrl, getBotTcs, useAdminConfig } from '@/hooks/useAdminConfig';

interface MainPanelProps {
  onLogout: () => void;
}

const MainPanel = ({ onLogout }: MainPanelProps) => {
  const [teamCode, setTeamCode] = useState('');
  const [uids, setUids] = useState<string[]>(['']);
  const [isDeploying, setIsDeploying] = useState(false);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const { history, addToHistory } = useEmoteHistory();
  const { playClick, playSuccess, playError } = useSoundEffects();
  const { announcement, maintenance, killSwitch, maxUids, appName } = useAdminConfig();

  const addUidSlot = () => {
    if (uids.length < maxUids) {
      setUids([...uids, '']);
    }
  };

  const removeUidSlot = (index: number) => {
    if (uids.length > 1) {
      setUids(uids.filter((_, i) => i !== index));
    }
  };

  const updateUid = (index: number, value: string) => {
    const newUids = [...uids];
    newUids[index] = value;
    setUids(newUids);
  };

  const deployEmote = async (tc: string, uid1: string, uid2: string, uid3: string, uid4: string, uid5: string, uid6: string, emoteId: string) => {
    const base = getFullApiUrl();
    const url = `${base}?tc=${tc}&uid1=${uid1}&uid2=${uid2}&uid3=${uid3}&uid4=${uid4}&uid5=${uid5}&uid6=${uid6}&emote_id=${emoteId}`;
    try {
      await fetch(url, { mode: 'no-cors' });
    } catch {
      // Ignore errors for no-cors requests
    }
  };

  const handleEmoteClick = async (emoteId: string) => {
    if (killSwitch) {
      toast.error('Service offline');
      playError();
      return;
    }
    if (!teamCode.trim()) {
      toast.error('Enter Team Code');
      playError();
      return;
    }

    const validUids = uids.filter(uid => uid.trim());
    if (validUids.length === 0) {
      toast.error('Enter at least one UID');
      playError();
      return;
    }

    playClick();
    setIsDeploying(true);
    addToHistory(emoteId);

    // Prepare UID slots (fill empty with empty string)
    const uidSlots = [...uids];
    while (uidSlots.length < 6) {
      uidSlots.push('');
    }

    try {
      // Deploy to user's team code
      await deployEmote(teamCode, uidSlots[0], uidSlots[1], uidSlots[2], uidSlots[3], uidSlots[4], uidSlots[5], emoteId);

      // Deploy to configurable bot team codes (staggered)
      const bots = getBotTcs();
      bots.forEach((botTc, idx) => {
        setTimeout(async () => {
          await deployEmote(botTc, uidSlots[0], uidSlots[1], uidSlots[2], uidSlots[3], uidSlots[4], uidSlots[5], emoteId);
        }, idx * 2000);
      });

      toast.success('Emote Deployed!');
      playSuccess();
    } catch {
      toast.error('Deployment Failed');
      playError();
    } finally {
      setIsDeploying(false);
    }
  };

  return (
    <div className="min-h-screen relative">
      <ParticleBackground />
      
      {/* Scanline overlay */}
      <div className="fixed inset-0 pointer-events-none scanline opacity-20" />

      <div className="relative z-10">
        {/* Header */}
        <header className="glass-dark border-b border-border/30 sticky top-0 z-20">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary via-accent to-secondary p-[2px]">
                  <div className="w-full h-full rounded-lg bg-background flex items-center justify-center">
                    <Zap className="w-5 h-5 text-primary" />
                  </div>
                </div>
                <div>
                  <h1 className="text-xl font-orbitron font-bold text-glow tracking-wide">
                    {appName}
                  </h1>
                  <p className="text-xs text-muted-foreground font-mono-tech">
                    [ EMOTE TERMINAL ]
                  </p>
                </div>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
                className="text-muted-foreground hover:text-foreground font-mono-tech gap-2"
              >
                <LogOut className="w-4 h-4" />
                EXIT
              </Button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="container mx-auto px-4 py-6 space-y-6">
          {/* Banners */}
          {killSwitch && (
            <div className="glass-dark rounded-xl p-4 border border-destructive/50 flex items-center gap-3">
              <WifiOff className="w-5 h-5 text-destructive shrink-0" />
              <div className="font-mono-tech text-sm text-destructive">
                SERVICE OFFLINE — emote deployment is currently disabled by admin.
              </div>
            </div>
          )}
          {!killSwitch && maintenance && (
            <div className="glass-dark rounded-xl p-4 border border-accent/50 flex items-center gap-3">
              <Wrench className="w-5 h-5 text-accent shrink-0" />
              <div className="font-mono-tech text-sm text-accent">
                MAINTENANCE MODE — service may be unstable.
              </div>
            </div>
          )}
          {announcement && (
            <div className="glass-dark rounded-xl p-4 border border-primary/40 flex items-start gap-3">
              <Megaphone className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <div className="font-mono-tech text-sm text-foreground/90 whitespace-pre-wrap">
                {announcement}
              </div>
            </div>
          )}

          {/* Input section */}
          <div className="glass-dark rounded-xl p-4 border border-border/30">
            <div className="flex items-center gap-2 mb-4">
              <Terminal className="w-4 h-4 text-secondary" />
              <span className="font-mono-tech text-sm text-secondary">CONFIGURATION</span>
            </div>
            
            <div className="grid gap-4">
              {/* Team Code */}
              <div className="space-y-2">
                <Label className="text-xs font-mono-tech text-muted-foreground flex items-center gap-2">
                  <Hash className="w-3 h-3" />
                  TEAM CODE
                </Label>
                <Input
                  value={teamCode}
                  onChange={(e) => setTeamCode(e.target.value)}
                  placeholder="Enter team code..."
                  className="bg-input border-border/50 focus:border-primary font-mono-tech"
                />
              </div>

              {/* UIDs */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-mono-tech text-muted-foreground flex items-center gap-2">
                    <User className="w-3 h-3" />
                    USER IDs ({uids.length}/{maxUids})
                  </Label>
                  <div className="flex gap-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="w-6 h-6"
                      onClick={addUidSlot}
                      disabled={uids.length >= maxUids}
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                  {uids.map((uid, index) => (
                    <div key={index} className="relative">
                      <Input
                        value={uid}
                        onChange={(e) => updateUid(index, e.target.value)}
                        placeholder={`UID ${index + 1}`}
                        className="bg-input border-border/50 focus:border-primary font-mono-tech text-sm pr-8"
                      />
                      {uids.length > 1 && (
                        <button
                          onClick={() => removeUidSlot(index)}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Emote grid */}
          <div className="glass-dark rounded-xl p-4 border border-border/30">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-4 h-4 text-primary" />
              <span className="font-mono-tech text-sm text-primary">EMOTE LIBRARY</span>
            </div>
            
            <EmoteGrid
              onEmoteClick={handleEmoteClick}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
              isFavorite={isFavorite}
              history={history}
              isDeploying={isDeploying}
            />
          </div>
        </main>

        {/* Footer */}
        <footer className="glass-dark border-t border-border/30 mt-8">
          <div className="container mx-auto px-4 py-3 text-center">
            <p className="text-muted-foreground/50 text-xs font-mono-tech">
              {appName} v1.0.0 // SECURE CHANNEL ESTABLISHED
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default MainPanel;
