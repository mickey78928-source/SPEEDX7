import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Lock, Eye, EyeOff, Zap, Users } from 'lucide-react';
import ParticleBackground from './ParticleBackground';
import { useVisitorCount } from '@/hooks/useVisitorCount';
import { useSoundEffects } from '@/hooks/useSoundEffects';

import { getUserPassword, useAdminConfig } from '@/hooks/useAdminConfig';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage = ({ onLogin }: LoginPageProps) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const visitorCount = useVisitorCount();
  const { playClick, playSuccess, playError } = useSoundEffects();
  const { appName } = useAdminConfig();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setIsLoading(true);
    setError('');

    await new Promise(resolve => setTimeout(resolve, 800));

    if (password === getUserPassword()) {
      playSuccess();
      onLogin();
    } else {
      playError();
      setError('Access Denied');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <ParticleBackground />
      
      {/* Scanline overlay */}
      <div className="fixed inset-0 pointer-events-none scanline opacity-10" />
      
      {/* Main content */}
      <div className="relative z-10 w-full max-w-md">
        {/* Logo and title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-primary/60 via-accent/60 to-secondary/60 p-[2px] mb-4">
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
              <span className="font-orbitron font-black text-2xl bg-gradient-to-br from-primary via-accent to-secondary bg-clip-text text-transparent tracking-tighter">
                EH
              </span>
            </div>
          </div>
          <h1 className="text-4xl font-orbitron font-bold text-glow-soft tracking-wider">
            {appName}
          </h1>
          <p className="text-muted-foreground mt-2 font-mono-tech text-sm tracking-widest">
            [ SECURE TERMINAL ]
          </p>
        </div>

        {/* Login form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="glass-dark rounded-xl p-6 border border-border/50 gradient-border">
            <div className="space-y-4">
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter access code..."
                  className="pl-11 pr-11 py-6 bg-input border-border/50 focus:border-primary focus:ring-primary/20 font-mono-tech text-lg tracking-widest"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              {error && (
                <div className="text-destructive text-sm font-mono-tech text-center animate-fade-in">
                  [ {error} ]
                </div>
              )}

              <Button
                type="submit"
                disabled={isLoading || !password}
                className="w-full py-6 font-orbitron text-lg tracking-wider bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] transition-all duration-500 shimmer"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    AUTHENTICATING...
                  </span>
                ) : (
                  'INITIALIZE'
                )}
              </Button>
            </div>
          </div>
        </form>

        {/* Visitor count */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center gap-2 glass-dark rounded-full px-4 py-2 border border-border/30">
            <Users className="w-4 h-4 text-secondary" />
            <span className="font-mono-tech text-sm text-muted-foreground">
              Visitors: <span className="text-secondary text-glow-cyan">{visitorCount}</span>
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-muted-foreground/50 text-xs font-mono-tech">
            v1.0.0 // ENCRYPTED CONNECTION
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
