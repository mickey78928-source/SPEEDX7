import { useState, useMemo } from 'react';
import { emotes, searchEmotes, getEmotesForPage, getTotalPages } from '@/data/emotes';
import EmoteCard from './EmoteCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, ChevronLeft, ChevronRight, Star, Clock } from 'lucide-react';

interface EmoteGridProps {
  onEmoteClick: (emoteId: string) => void;
  favorites: string[];
  onToggleFavorite: (emoteId: string) => void;
  isFavorite: (emoteId: string) => boolean;
  history: string[];
  isDeploying: boolean;
}

const EmoteGrid = ({
  onEmoteClick,
  favorites,
  onToggleFavorite,
  isFavorite,
  history,
  isDeploying,
}: EmoteGridProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [showFavorites, setShowFavorites] = useState(false);

  const totalPages = getTotalPages();

  const displayedEmotes = useMemo(() => {
    if (showFavorites) {
      return emotes.filter(e => favorites.includes(e.id));
    }
    if (searchQuery.trim()) {
      return searchEmotes(searchQuery);
    }
    return getEmotesForPage(currentPage);
  }, [searchQuery, currentPage, showFavorites, favorites]);

  const historyEmotes = useMemo(() => {
    return history.map(id => emotes.find(e => e.id === id)).filter(Boolean);
  }, [history]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    setSearchQuery('');
    setShowFavorites(false);
  };

  return (
    <div className="space-y-4">
      {/* Search and filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search emotes..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowFavorites(false);
            }}
            className="pl-10 bg-input border-border/50 focus:border-primary focus:ring-primary/20 font-mono-tech"
          />
        </div>
        <Button
          variant={showFavorites ? "default" : "outline"}
          onClick={() => {
            setShowFavorites(!showFavorites);
            setSearchQuery('');
          }}
          className="gap-2 font-rajdhani"
        >
          <Star className={`w-4 h-4 ${showFavorites ? 'fill-current' : ''}`} />
          Favorites ({favorites.length})
        </Button>
      </div>

      {/* Recent history */}
      {history.length > 0 && !searchQuery && !showFavorites && (
        <div className="glass-dark rounded-lg p-3 border border-border/30">
          <div className="flex items-center gap-2 mb-2 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span className="text-sm font-mono-tech">Recent</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {historyEmotes.slice(0, 8).map((emote) => emote && (
              <div
                key={emote.id}
                onClick={() => onEmoteClick(emote.id)}
                className="flex-shrink-0 w-12 h-12 glass-dark rounded-lg p-1 border border-border/30 cursor-pointer hover:border-primary/60 transition-all hover:scale-105"
              >
                <img
                  src={`https://cdn.jsdelivr.net/gh/ShahGCreator/icon@main/PNG/${emote.id}.png`}
                  alt={emote.name}
                  className="w-full h-full object-contain"
                  style={{ filter: 'drop-shadow(0 0 4px hsl(280, 100%, 60%))' }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Emote grid */}
      <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2">
        {displayedEmotes.map((emote) => (
          <EmoteCard
            key={emote.id}
            emoteId={emote.id}
            onClick={() => onEmoteClick(emote.id)}
            isFavorite={isFavorite(emote.id)}
            onToggleFavorite={() => onToggleFavorite(emote.id)}
            isLoading={isDeploying}
          />
        ))}
      </div>

      {displayedEmotes.length === 0 && (
        <div className="text-center py-12 text-muted-foreground font-mono-tech">
          {showFavorites ? 'No favorites yet' : 'No emotes found'}
        </div>
      )}

      {/* Pagination */}
      {!searchQuery && !showFavorites && (
        <div className="flex items-center justify-center gap-2 pt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="gap-1 font-mono-tech"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <div className="flex gap-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                size="sm"
                onClick={() => handlePageChange(page)}
                className={`w-8 h-8 p-0 font-mono-tech ${
                  currentPage === page ? 'box-glow' : ''
                }`}
              >
                {page}
              </Button>
            ))}
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="gap-1 font-mono-tech"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default EmoteGrid;
