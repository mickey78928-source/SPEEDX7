import { useState } from 'react';
import { getEmoteImageUrl } from '@/data/emotes';
import { Skeleton } from '@/components/ui/skeleton';
import { Heart } from 'lucide-react';

interface EmoteCardProps {
  emoteId: string;
  onClick: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  isLoading?: boolean;
}

const EmoteCard = ({ emoteId, onClick, isFavorite, onToggleFavorite, isLoading }: EmoteCardProps) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClick();
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite();
  };

  if (isLoading) {
    return (
      <div className="relative group">
        <div className="glass-dark rounded-lg p-3 border border-border/30 aspect-square flex items-center justify-center">
          <Skeleton className="w-full h-full rounded-md bg-muted/50" />
        </div>
      </div>
    );
  }

  return (
    <div className="relative group cursor-pointer" onClick={handleClick}>
      <div className="glass-dark rounded-lg p-2 border border-border/30 aspect-square flex items-center justify-center transition-all duration-300 hover:border-primary/60 hover:box-glow group-hover:scale-105 overflow-hidden">
        {/* Glow effect behind image */}
        <div className="absolute inset-0 bg-gradient-radial from-primary/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {!imageLoaded && !imageError && (
          <Skeleton className="w-full h-full rounded-md bg-muted/50 absolute inset-2" />
        )}
        
        {imageError ? (
          <div className="text-muted-foreground text-xs text-center">Failed</div>
        ) : (
          <img
            src={getEmoteImageUrl(emoteId)}
            alt={`Emote ${emoteId}`}
            className={`w-full h-full object-contain transition-all duration-300 group-hover:scale-110 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              filter: 'drop-shadow(0 0 8px hsl(280, 100%, 60%))',
            }}
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
            loading="lazy"
          />
        )}
        
        {/* Favorite button */}
        <button
          onClick={handleFavoriteClick}
          className="absolute top-1 right-1 p-1 rounded-full bg-background/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-background/80 hover:scale-110 z-10"
        >
          <Heart
            className={`w-3 h-3 transition-colors ${
              isFavorite ? 'fill-accent text-accent' : 'text-muted-foreground'
            }`}
          />
        </button>
      </div>
    </div>
  );
};

export default EmoteCard;
