import { useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import {
  Shield, LogOut, Users, Heart, History, Trash2, RefreshCw,
  Activity, Database, Link as LinkIcon, KeyRound, Bot, Plus, X, Save,
  Megaphone, Power, Wrench, Download, Upload, Wifi, WifiOff, Settings,
  CheckCircle2, XCircle, Clock,
} from 'lucide-react';
import { toast } from 'sonner';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { useAdminConfig, DEFAULT_API_URL, DEFAULT_API_PATH, getFullApiUrl } from '@/hooks/useAdminConfig';

interface AdminPanelProps {
  onLogout: () => void;
}

const VISITOR_KEY = 'unknown_codex_visitors';
const VISITOR_ID_KEY = 'unknown_codex_visitor_id';
const FAVORITES_KEY = 'unknown_codex_favorites';
const HISTORY_KEY = 'unknown_codex_history';

const AdminPanel = ({ onLogout }: AdminPanelProps) => {
  const { playClick, playSuccess, playError } = useSoundEffects();
  const cfg = useAdminConfig();

  const [stats, setStats] = useState({ visitors: 0, favorites: 0, history: 0 });
  const [newVisitorCount, setNewVisitorCount] = useState('');
  const [apiInput, setApiInput] = useState(cfg.apiUrl);
  const [apiPathInput, setApiPathInput] = useState(cfg.apiPath);
  const [userPassInput, setUserPassInput] = useState('');
  const [adminPassInput, setAdminPassInput] = useState('');
  const [newBotTc, setNewBotTc] = useState('');
  const [annInput, setAnnInput] = useState(cfg.announcement);
  const [appNameInput, setAppNameInput] = useState(cfg.appName);
  const [pingStatus, setPingStatus] = useState<'idle' | 'pinging' | 'ok' | 'fail'>('idle');
  const [pingMs, setPingMs] = useState<number | null>(null);

  const refreshStats = () => {
    const visitors = parseInt(localStorage.getItem(VISITOR_KEY) || '0', 10);
    const favorites = JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]').length;
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]').length;
    setStats({ visitors, favorites, history });
  };

  useEffect(() => { refreshStats(); }, []);
  useEffect(() => { setApiInput(cfg.apiUrl); }, [cfg.apiUrl]);
  useEffect(() => { setApiPathInput(cfg.apiPath); }, [cfg.apiPath]);
  useEffect(() => { setAnnInput(cfg.announcement); }, [cfg.announcement]);
  useEffect(() => { setAppNameInput(cfg.appName); }, [cfg.appName]);

  const sessionStart = useMemo(() => Date.now(), []);
  const [uptime, setUptime] = useState('00:00');
  useEffect(() => {
    const t = setInterval(() => {
      const s = Math.floor((Date.now() - sessionStart) / 1000);
      const m = String(Math.floor(s / 60)).padStart(2, '0');
      const ss = String(s % 60).padStart(2, '0');
      setUptime(`${m}:${ss}`);
    }, 1000);
    return () => clearInterval(t);
  }, [sessionStart]);

  // ---- Stats actions
  const handleResetVisitors = () => {
    playClick();
    localStorage.setItem(VISITOR_KEY, '0');
    localStorage.removeItem(VISITOR_ID_KEY);
    refreshStats(); playSuccess(); toast.success('Visitor count reset');
  };
  const handleSetVisitors = () => {
    const n = parseInt(newVisitorCount, 10);
    if (isNaN(n) || n < 0) { playError(); toast.error('Invalid number'); return; }
    playClick();
    localStorage.setItem(VISITOR_KEY, n.toString());
    setNewVisitorCount(''); refreshStats(); playSuccess();
    toast.success(`Visitor count set to ${n}`);
  };
  const handleClearFavorites = () => {
    playClick(); localStorage.removeItem(FAVORITES_KEY); refreshStats(); playSuccess();
    toast.success('Favorites cleared');
  };
  const handleClearHistory = () => {
    playClick(); localStorage.removeItem(HISTORY_KEY); refreshStats(); playSuccess();
    toast.success('History cleared');
  };
  const handleClearAll = () => {
    if (!confirm('Wipe ALL local data?')) return;
    playClick(); localStorage.clear(); refreshStats(); playSuccess();
    toast.success('All data wiped');
  };

  // ---- API
  const handleSaveApi = () => {
    if (!apiInput.trim().startsWith('http')) { playError(); toast.error('Invalid URL — must start with http(s)://'); return; }
    playClick();
    cfg.setApiUrl(apiInput.trim().replace(/\/+$/, ''));
    cfg.setApiPath(apiPathInput.trim());
    playSuccess();
    toast.success('API endpoint updated');
  };
  const handleResetApi = () => {
    playClick(); cfg.resetApiUrl(); cfg.resetApiPath();
    playSuccess(); toast.success('API endpoint reset');
  };
  const handlePingApi = async () => {
    playClick(); setPingStatus('pinging'); setPingMs(null);
    const start = performance.now();
    try {
      await fetch(getFullApiUrl(), { mode: 'no-cors' });
      const ms = Math.round(performance.now() - start);
      setPingMs(ms); setPingStatus('ok'); playSuccess();
      toast.success(`API reachable in ${ms}ms`);
    } catch {
      setPingStatus('fail'); playError(); toast.error('API unreachable');
    }
  };

  // ---- Passwords
  const handleSaveUserPass = () => {
    if (!userPassInput.trim()) { playError(); toast.error('Empty password'); return; }
    playClick(); cfg.setUserPassword(userPassInput.trim()); setUserPassInput(''); playSuccess();
    toast.success('User password updated');
  };
  const handleSaveAdminPass = () => {
    if (!adminPassInput.trim()) { playError(); toast.error('Empty password'); return; }
    playClick(); cfg.setAdminPassword(adminPassInput.trim()); setAdminPassInput(''); playSuccess();
    toast.success('Admin password updated');
  };

  // ---- Bots
  const handleAddBotTc = () => {
    if (!newBotTc.trim()) return;
    playClick(); cfg.addBotTc(newBotTc.trim()); setNewBotTc(''); playSuccess();
    toast.success('Bot team code added');
  };
  const handleRemoveBotTc = (tc: string) => {
    playClick(); cfg.removeBotTc(tc); playSuccess(); toast.success('Bot removed');
  };

  // ---- System
  const handleSaveAnn = () => {
    playClick(); cfg.setAnnouncement(annInput); playSuccess();
    toast.success(annInput ? 'Announcement updated' : 'Announcement cleared');
  };
  const handleSaveAppName = () => {
    if (!appNameInput.trim()) { playError(); toast.error('Empty name'); return; }
    playClick(); cfg.setAppName(appNameInput.trim()); playSuccess();
    toast.success('App name updated');
  };

  // ---- Export / import
  const handleExport = () => {
    playClick();
    const data = JSON.stringify(cfg.exportConfig(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `exu-config-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
    playSuccess(); toast.success('Config exported');
  };
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        cfg.importConfig(parsed); playSuccess(); toast.success('Config imported');
      } catch { playError(); toast.error('Invalid config file'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      {/* Header */}
      <header className="max-w-6xl mx-auto mb-6 flex items-center justify-between glass-dark rounded-xl p-4 border border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/60 to-accent/60 p-[2px]">
            <div className="w-full h-full rounded-md bg-background flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div>
            <h1 className="font-orbitron font-bold text-xl tracking-wider text-glow-soft">
              ADMIN CONSOLE
            </h1>
            <p className="font-mono-tech text-xs text-muted-foreground">
              [ ROOT // SESSION {uptime} ]
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-2 glass-dark px-3 py-1.5 rounded-md border border-border/40">
            {cfg.killSwitch ? (
              <><WifiOff className="w-4 h-4 text-destructive" /><span className="font-mono-tech text-xs text-destructive">OFFLINE</span></>
            ) : cfg.maintenance ? (
              <><Wrench className="w-4 h-4 text-accent" /><span className="font-mono-tech text-xs text-accent">MAINTENANCE</span></>
            ) : (
              <><Wifi className="w-4 h-4 text-primary" /><span className="font-mono-tech text-xs text-primary">LIVE</span></>
            )}
          </div>
          <Button
            variant="outline"
            onClick={() => { playClick(); onLogout(); }}
            className="font-mono-tech border-border/50 hover:bg-destructive/20 hover:border-destructive/50"
          >
            <LogOut className="w-4 h-4 mr-2" />EXIT
          </Button>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="glass-dark border-border/50 p-5">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono-tech text-xs text-muted-foreground tracking-widest">VISITORS</span>
            <Users className="w-4 h-4 text-primary" />
          </div>
          <div className="font-orbitron text-2xl font-bold text-primary">{stats.visitors}</div>
        </Card>
        <Card className="glass-dark border-border/50 p-5">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono-tech text-xs text-muted-foreground tracking-widest">FAVORITES</span>
            <Heart className="w-4 h-4 text-accent" />
          </div>
          <div className="font-orbitron text-2xl font-bold text-accent">{stats.favorites}</div>
        </Card>
        <Card className="glass-dark border-border/50 p-5">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono-tech text-xs text-muted-foreground tracking-widest">HISTORY</span>
            <History className="w-4 h-4 text-secondary" />
          </div>
          <div className="font-orbitron text-2xl font-bold text-secondary">{stats.history}</div>
        </Card>
        <Card className="glass-dark border-border/50 p-5">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono-tech text-xs text-muted-foreground tracking-widest">BOTS</span>
            <Bot className="w-4 h-4 text-primary" />
          </div>
          <div className="font-orbitron text-2xl font-bold text-primary">{cfg.botTcs.length}</div>
        </Card>
      </div>

      {/* Tabs */}
      <div className="max-w-6xl mx-auto">
        <Tabs defaultValue="system" className="w-full">
          <TabsList className="glass-dark border border-border/50 grid grid-cols-3 md:grid-cols-6 w-full mb-4 h-auto">
            <TabsTrigger value="system" className="font-mono-tech"><Settings className="w-4 h-4 mr-2" />SYSTEM</TabsTrigger>
            <TabsTrigger value="api" className="font-mono-tech"><LinkIcon className="w-4 h-4 mr-2" />API</TabsTrigger>
            <TabsTrigger value="auth" className="font-mono-tech"><KeyRound className="w-4 h-4 mr-2" />AUTH</TabsTrigger>
            <TabsTrigger value="bots" className="font-mono-tech"><Bot className="w-4 h-4 mr-2" />BOTS</TabsTrigger>
            <TabsTrigger value="data" className="font-mono-tech"><Database className="w-4 h-4 mr-2" />DATA</TabsTrigger>
            <TabsTrigger value="backup" className="font-mono-tech"><Download className="w-4 h-4 mr-2" />BACKUP</TabsTrigger>
          </TabsList>

          {/* SYSTEM */}
          <TabsContent value="system" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="glass-dark border-border/50 p-6 space-y-4">
                <div className="flex items-center gap-2">
                  <Power className="w-5 h-5 text-primary" />
                  <h2 className="font-orbitron font-bold tracking-wider">SYSTEM STATE</h2>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-input/50 border border-border/40">
                  <div>
                    <Label className="font-mono-tech">Maintenance Mode</Label>
                    <p className="text-xs text-muted-foreground font-mono-tech mt-1">
                      Show banner; deployments still work.
                    </p>
                  </div>
                  <Switch
                    checked={cfg.maintenance}
                    onCheckedChange={(v) => { playClick(); cfg.setMaintenance(v); toast.success(`Maintenance ${v ? 'ON' : 'OFF'}`); }}
                  />
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-input/50 border border-destructive/40">
                  <div>
                    <Label className="font-mono-tech text-destructive">Kill Switch</Label>
                    <p className="text-xs text-muted-foreground font-mono-tech mt-1">
                      Block all emote deployments instantly.
                    </p>
                  </div>
                  <Switch
                    checked={cfg.killSwitch}
                    onCheckedChange={(v) => { playClick(); cfg.setKillSwitch(v); toast.success(`Kill switch ${v ? 'ENGAGED' : 'RELEASED'}`); }}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-mono-tech text-xs text-muted-foreground">
                    MAX UID SLOTS: <span className="text-primary">{cfg.maxUids}</span>
                  </Label>
                  <Slider
                    value={[cfg.maxUids]}
                    min={1} max={12} step={1}
                    onValueChange={(v) => cfg.setMaxUids(v[0])}
                  />
                </div>
              </Card>

              <Card className="glass-dark border-border/50 p-6 space-y-4">
                <div className="flex items-center gap-2">
                  <Megaphone className="w-5 h-5 text-accent" />
                  <h2 className="font-orbitron font-bold tracking-wider">BROADCAST</h2>
                </div>
                <p className="font-mono-tech text-xs text-muted-foreground">
                  Announcement banner shown to all users on the main panel.
                </p>
                <Textarea
                  value={annInput}
                  onChange={(e) => setAnnInput(e.target.value)}
                  placeholder="Broadcast a message to all users..."
                  rows={4}
                  className="bg-input border-border/50 font-mono-tech"
                />
                <div className="flex gap-2">
                  <Button onClick={handleSaveAnn} className="font-mono-tech flex-1">
                    <Save className="w-4 h-4 mr-2" />BROADCAST
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => { setAnnInput(''); cfg.setAnnouncement(''); playClick(); toast.success('Announcement cleared'); }}
                    className="font-mono-tech border-border/50"
                  >
                    CLEAR
                  </Button>
                </div>

                <div className="pt-2 border-t border-border/40 space-y-2">
                  <Label className="font-mono-tech text-xs text-muted-foreground">APP NAME</Label>
                  <div className="flex gap-2">
                    <Input
                      value={appNameInput}
                      onChange={(e) => setAppNameInput(e.target.value)}
                      className="bg-input border-border/50 font-mono-tech"
                    />
                    <Button onClick={handleSaveAppName} className="font-mono-tech">
                      <Save className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* API */}
          <TabsContent value="api" className="space-y-4">
            <Card className="glass-dark border-border/50 p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <LinkIcon className="w-5 h-5 text-primary" />
                  <h2 className="font-orbitron font-bold tracking-wider">API ENDPOINT</h2>
                </div>
                <span className="font-mono-tech text-[10px] tracking-widest px-2 py-1 rounded border border-border/40 bg-input/40 text-muted-foreground">
                  LOCAL STORAGE
                </span>
              </div>
              <p className="font-mono-tech text-xs text-muted-foreground leading-relaxed">
                Configure the deployment server. The full request URL is built as
                <span className="text-primary"> Base URL + Endpoint Path + Query</span>.
                All settings persist in this browser's local storage — no cloud database is used.
              </p>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-mono-tech text-xs text-muted-foreground tracking-wider">
                    BASE URL
                  </Label>
                  <Input
                    value={apiInput}
                    onChange={(e) => setApiInput(e.target.value)}
                    placeholder={DEFAULT_API_URL}
                    className="bg-input border-border/50 font-mono-tech"
                  />
                  <p className="text-[11px] font-mono-tech text-muted-foreground/70">
                    e.g. <span className="text-primary/80">https://exu-api-2.onrender.com</span>
                  </p>
                </div>

                <div className="space-y-2">
                  <Label className="font-mono-tech text-xs text-muted-foreground tracking-wider">
                    ENDPOINT PATH
                  </Label>
                  <Input
                    value={apiPathInput}
                    onChange={(e) => setApiPathInput(e.target.value)}
                    placeholder={DEFAULT_API_PATH}
                    className="bg-input border-border/50 font-mono-tech"
                  />
                  <p className="text-[11px] font-mono-tech text-muted-foreground/70">
                    e.g. <span className="text-primary/80">/join</span>,{' '}
                    <span className="text-primary/80">/api/emote</span>,{' '}
                    <span className="text-primary/80">/v2/deploy</span>
                  </p>
                </div>
              </div>

              {/* Live preview */}
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                  <span className="font-mono-tech text-[10px] tracking-widest text-primary">LIVE PREVIEW</span>
                </div>
                <div className="font-mono-tech text-xs text-foreground break-all">
                  <span className="text-muted-foreground">URL: </span>
                  <span className="text-primary">{(apiInput || DEFAULT_API_URL).replace(/\/+$/, '')}</span>
                  <span className="text-accent">{(apiPathInput.startsWith('/') || !apiPathInput) ? apiPathInput : '/' + apiPathInput}</span>
                  <span className="text-muted-foreground">?tc=</span><span className="text-foreground">123456</span>
                  <span className="text-muted-foreground">&uid1=</span><span className="text-foreground">XXXX</span>
                  <span className="text-muted-foreground">&uid2=</span><span className="text-foreground">…</span>
                  <span className="text-muted-foreground">&emote_id=</span><span className="text-foreground">EMOTE_001</span>
                </div>
              </div>

              {/* Example block */}
              <div className="rounded-lg border border-border/40 bg-input/40 p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Settings className="w-3.5 h-3.5 text-secondary" />
                  <span className="font-mono-tech text-[10px] tracking-widest text-secondary">EXAMPLE — HOW TO ADD A NEW API</span>
                </div>
                <pre className="text-[11px] font-mono-tech text-foreground/85 leading-relaxed whitespace-pre-wrap">
{`1. Set BASE URL    → https://my-emote-api.example.com
2. Set ENDPOINT    → /api/v1/emote/send
3. Press SAVE

Final request sent by the panel:
  https://my-emote-api.example.com/api/v1/emote/send
    ?tc=<TEAM_CODE>
    &uid1=<UID>&uid2=<UID>&uid3=<UID>
    &uid4=<UID>&uid5=<UID>&uid6=<UID>
    &emote_id=<EMOTE_ID>

Your server should accept GET requests with the
above query params and trigger the emote.`}
                </pre>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <Button onClick={handleSaveApi} className="font-mono-tech">
                  <Save className="w-4 h-4 mr-2" />SAVE
                </Button>
                <Button variant="outline" onClick={handleResetApi} className="font-mono-tech border-border/50">
                  <RefreshCw className="w-4 h-4 mr-2" />RESET DEFAULT
                </Button>
                <Button variant="outline" onClick={handlePingApi} className="font-mono-tech border-border/50">
                  {pingStatus === 'pinging' ? <Clock className="w-4 h-4 mr-2 animate-spin" /> :
                    pingStatus === 'ok' ? <CheckCircle2 className="w-4 h-4 mr-2 text-primary" /> :
                    pingStatus === 'fail' ? <XCircle className="w-4 h-4 mr-2 text-destructive" /> :
                    <Activity className="w-4 h-4 mr-2" />}
                  PING {pingMs !== null && `(${pingMs}ms)`}
                </Button>
                <div className="ml-auto font-mono-tech text-[11px] text-muted-foreground break-all">
                  Active: <span className="text-primary">{cfg.apiUrl}</span>
                  <span className="text-accent">{cfg.apiPath}</span>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* AUTH */}
          <TabsContent value="auth">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="glass-dark border-border/50 p-6 space-y-4">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-primary" />
                  <h2 className="font-orbitron font-bold tracking-wider">USER PASSWORD</h2>
                </div>
                <p className="font-mono-tech text-xs text-muted-foreground">
                  Current: <span className="text-primary">{cfg.userPassword}</span>
                </p>
                <Input
                  type="text"
                  value={userPassInput}
                  onChange={(e) => setUserPassInput(e.target.value)}
                  placeholder="New user password..."
                  className="bg-input border-border/50 font-mono-tech"
                />
                <Button onClick={handleSaveUserPass} className="w-full font-mono-tech">
                  <Save className="w-4 h-4 mr-2" />UPDATE USER PASSWORD
                </Button>
              </Card>

              <Card className="glass-dark border-border/50 p-6 space-y-4">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-accent" />
                  <h2 className="font-orbitron font-bold tracking-wider">ADMIN PASSWORD</h2>
                </div>
                <p className="font-mono-tech text-xs text-muted-foreground">
                  Current: <span className="text-accent">{cfg.adminPassword}</span>
                </p>
                <Input
                  type="text"
                  value={adminPassInput}
                  onChange={(e) => setAdminPassInput(e.target.value)}
                  placeholder="New admin password..."
                  className="bg-input border-border/50 font-mono-tech"
                />
                <Button onClick={handleSaveAdminPass} className="w-full font-mono-tech">
                  <Save className="w-4 h-4 mr-2" />UPDATE ADMIN PASSWORD
                </Button>
              </Card>
            </div>
          </TabsContent>

          {/* BOTS */}
          <TabsContent value="bots">
            <Card className="glass-dark border-border/50 p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-primary" />
                <h2 className="font-orbitron font-bold tracking-wider">BOT TEAM CODES</h2>
              </div>
              <p className="font-mono-tech text-xs text-muted-foreground">
                Emote requests are mirrored (staggered 2s) to each bot team code below.
              </p>

              <div className="flex gap-2">
                <Input
                  value={newBotTc}
                  onChange={(e) => setNewBotTc(e.target.value)}
                  placeholder="Add bot team code..."
                  className="bg-input border-border/50 font-mono-tech"
                />
                <Button onClick={handleAddBotTc} className="font-mono-tech">
                  <Plus className="w-4 h-4 mr-2" />ADD
                </Button>
              </div>

              <div className="space-y-2">
                {cfg.botTcs.length === 0 && (
                  <p className="font-mono-tech text-xs text-muted-foreground text-center py-4">
                    No bot team codes configured.
                  </p>
                )}
                {cfg.botTcs.map((tc, i) => (
                  <div
                    key={tc}
                    className="flex items-center justify-between bg-input/50 border border-border/50 rounded-lg px-3 py-2"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono-tech text-xs text-muted-foreground">#{i + 1}</span>
                      <span className="font-mono-tech text-primary">{tc}</span>
                    </div>
                    <Button
                      size="icon" variant="ghost"
                      onClick={() => handleRemoveBotTc(tc)}
                      className="h-7 w-7 hover:bg-destructive/20 hover:text-destructive"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* DATA */}
          <TabsContent value="data">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="glass-dark border-border/50 p-6 space-y-3">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-primary" />
                  <h2 className="font-orbitron font-bold tracking-wider">VISITOR CONTROL</h2>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder="Set visitor count..."
                    value={newVisitorCount}
                    onChange={(e) => setNewVisitorCount(e.target.value)}
                    className="bg-input border-border/50 font-mono-tech"
                  />
                  <Button onClick={handleSetVisitors} className="font-mono-tech">SET</Button>
                </div>
                <Button variant="outline" onClick={handleResetVisitors} className="w-full font-mono-tech border-border/50">
                  <RefreshCw className="w-4 h-4 mr-2" />RESET COUNTER
                </Button>
              </Card>

              <Card className="glass-dark border-border/50 p-6 space-y-3">
                <div className="flex items-center gap-2 mb-2">
                  <Database className="w-5 h-5 text-accent" />
                  <h2 className="font-orbitron font-bold tracking-wider">DATA CONTROL</h2>
                </div>
                <Button variant="outline" onClick={handleClearFavorites} className="w-full font-mono-tech border-border/50 justify-start">
                  <Heart className="w-4 h-4 mr-2" />CLEAR FAVORITES
                </Button>
                <Button variant="outline" onClick={handleClearHistory} className="w-full font-mono-tech border-border/50 justify-start">
                  <History className="w-4 h-4 mr-2" />CLEAR HISTORY
                </Button>
                <Button variant="outline" onClick={handleClearAll} className="w-full font-mono-tech border-destructive/50 text-destructive hover:bg-destructive/20 justify-start">
                  <Trash2 className="w-4 h-4 mr-2" />WIPE ALL DATA
                </Button>
              </Card>
            </div>
          </TabsContent>

          {/* BACKUP */}
          <TabsContent value="backup">
            <Card className="glass-dark border-border/50 p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-primary" />
                <h2 className="font-orbitron font-bold tracking-wider">CONFIG BACKUP</h2>
              </div>
              <p className="font-mono-tech text-xs text-muted-foreground">
                Export the entire admin configuration as a JSON file, or import a previously exported file to restore settings.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button onClick={handleExport} className="font-mono-tech">
                  <Download className="w-4 h-4 mr-2" />EXPORT CONFIG
                </Button>
                <label className="inline-flex">
                  <input type="file" accept="application/json" onChange={handleImport} className="hidden" />
                  <span className="inline-flex items-center px-4 py-2 rounded-md font-mono-tech text-sm border border-border/50 bg-input/50 hover:bg-input cursor-pointer">
                    <Upload className="w-4 h-4 mr-2" />IMPORT CONFIG
                  </span>
                </label>
              </div>

              <pre className="bg-input/50 border border-border/40 rounded-lg p-3 text-xs font-mono-tech text-muted-foreground overflow-auto max-h-64">
{JSON.stringify(cfg.exportConfig(), null, 2)}
              </pre>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <div className="max-w-6xl mx-auto mt-8 text-center space-y-1">
        <p className="font-mono-tech text-xs text-muted-foreground/60">
          {cfg.appName} // ADMIN CONSOLE v2.1.0
        </p>
        <p className="font-mono-tech text-[10px] text-muted-foreground/40 tracking-widest">
          ALL SETTINGS PERSIST IN BROWSER LOCAL STORAGE — NO CLOUD DATABASE
        </p>
      </div>
    </div>
  );
};

export default AdminPanel;
