import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Shield, Eye, EyeOff } from 'lucide-react';
import ParticleBackground from './ParticleBackground';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { getAdminPassword } from '@/hooks/useAdminConfig';

interface AdminLoginProps {
  onLogin: () => void;
}

const AdminLogin = ({ onLogin }: AdminLoginProps) => {
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { playClick, playSuccess, playError } = useSoundEffects();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setLoading(true);
    setError('');
    await new Promise((r) => setTimeout(r, 500));

    if (password === getAdminPassword()) {
      playSuccess();
      onLogin();
    } else {
      playError();
      setError('Unauthorized');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <ParticleBackground />
      <div className="fixed inset-0 pointer-events-none scanline opacity-10" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-primary/60 to-accent/60 p-[2px] mb-4">
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
              <Shield className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-orbitron font-bold text-glow-soft tracking-wider">
            ADMIN ACCESS
          </h1>
          <p className="text-muted-foreground mt-2 font-mono-tech text-sm tracking-widest">
            [ ROOT TERMINAL ]
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="glass-dark rounded-xl p-6 border border-border/50">
            <div className="space-y-4">
              <div className="relative">
                <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type={show ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Admin password..."
                  className="pl-11 pr-11 py-6 bg-input border-border/50 focus:border-primary font-mono-tech text-lg tracking-widest"
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              {error && (
                <div className="text-destructive text-sm font-mono-tech text-center">
                  [ {error} ]
                </div>
              )}

              <Button
                type="submit"
                disabled={loading || !password}
                className="w-full py-6 font-orbitron text-lg tracking-wider bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] transition-all duration-500"
              >
                {loading ? 'VERIFYING...' : 'AUTHORIZE'}
              </Button>
            </div>
          </div>
        </form>

        <p className="mt-6 text-center text-xs font-mono-tech text-muted-foreground/50">
          Restricted area // unauthorized access prohibited
        </p>
      </div>
    </div>
  );
};

export default AdminLogin;
